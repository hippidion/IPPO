// IPPO Assignment 2, Version 19.11, §PUBDATE
public class Main {
    public static void main(String[] args) {
        App.main(args);
    }
}
